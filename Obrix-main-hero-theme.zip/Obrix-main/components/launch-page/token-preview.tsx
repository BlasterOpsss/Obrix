'use client'

import { Card } from '@/components/ui/card'
import { MessageCircle, Globe, Sparkles, Radio, ShieldCheck } from 'lucide-react'

interface TokenPreviewProps {
  image?: string
  name: string
  symbol: string
  description: string
  xLink: string
  telegram: string
  website: string
}


export function TokenPreview({
  image,
  name,
  symbol,
  description,
  xLink,
  telegram,
  website,
}: TokenPreviewProps) {

  return (
    <Card className="neon-glow neon-border relative overflow-hidden h-fit sticky top-24 bg-[#0c0e10]">
      {/* Sparkle background effect */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-gradient-to-br from-[#d4d4d4]/10 via-transparent to-white/[0.02]" />
      </div>

      <div className="relative p-6 space-y-6">
        {/* Header with sparkle icon */}
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="h-4 w-4 text-[#d4d4d4]" />
          <h3 className="text-lg font-semibold tracking-tight text-white">
            Live Preview
          </h3>
        </div>

        {/* Token Logo */}
        <div className="flex justify-center">
          {image ? (
            <img
              src={image}
              alt={`${symbol} logo`}
              className="h-40 w-40 rounded-2xl object-cover border border-white/15 shadow-2xl"
            />
          ) : (
            <div className="h-40 w-40 rounded-2xl bg-white/[0.03] border border-white/10 flex items-center justify-center">
              <span className="text-sm text-muted-foreground">No image</span>
            </div>
          )}
        </div>

        {/* Token Info */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-2">
            <h2 className="text-2xl font-bold text-foreground">
              {name || 'Your Token'}
            </h2>
            <span className="text-lg font-semibold text-[#d4d4d4]">
              {symbol || 'TKN'}
            </span>
          </div>
          <p className="text-sm text-muted-foreground line-clamp-3">
            {description || 'Token description appears here...'}
          </p>
        </div>

        {/* Social Links */}
        <div className="flex justify-center gap-3">
          {xLink && (
            <a
              href={xLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center h-10 w-10 rounded-xl border border-white/10 bg-white/[0.04] hover:bg-white/[0.08] transition-colors"
              title="X (Twitter)"
            >
              <Radio className="h-5 w-5 text-[#d4d4d4]" />
            </a>
          )}
          {telegram && (
            <a
              href={`https://t.me/${telegram.replace('t.me/', '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center h-10 w-10 rounded-xl border border-white/10 bg-white/[0.04] hover:bg-white/[0.08] transition-colors"
              title="Telegram"
            >
              <MessageCircle className="h-5 w-5 text-[#d4d4d4]" />
            </a>
          )}
          {website && (
            <a
              href={website}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center h-10 w-10 rounded-xl border border-white/10 bg-white/[0.04] hover:bg-white/[0.08] transition-colors"
              title="Website"
            >
              <Globe className="h-5 w-5 text-[#d4d4d4]" />
            </a>
          )}
        </div>

        <div className="rounded-xl border border-white/10 bg-white/[0.025] p-4">
          <div className="mb-2 flex items-center gap-2 text-xs font-medium uppercase tracking-[0.16em] text-[#d4d4d4]">
            <ShieldCheck className="h-4 w-4" /> Pons V2 launch flow
          </div>
          <p className="text-xs leading-5 text-zinc-500">Fixed supply is minted to its bonding curve. If the curve completes, the launch graduates into a Uniswap V4 pool with locked liquidity. This preview does not estimate market cap or liquidity.</p>
        </div>

        <p className="text-center pt-1 text-[10px] uppercase tracking-[0.16em] text-zinc-600">
          Preview only · Verify every transaction in your wallet
        </p>
      </div>
    </Card>
  )
}
