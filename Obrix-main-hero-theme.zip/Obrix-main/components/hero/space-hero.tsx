'use client'

import { useEffect, useRef, useState } from 'react'
import '@/app/hero.css'

const VIDEO_SRC = 'https://d2ol7oe51mr4n9.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/4b73c700-3112-4c07-bd48-0af2893dff7c.mp4'
const POSTER_SRC = 'https://d2ol7oe51mr4n9.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/0bf7409c-9fa2-4bef-a49d-34903dcc91ad.png'
const FONT_HREF = 'https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,100..900&display=block'

// Copy + links live here so they are easy to change.
const BRAND = 'Obrix'
const NAV = [
  { label: 'About', href: '#about' },
  { label: 'Features', href: '#features' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Contact', href: '#contact' },
  { label: 'Blog', href: '#blog' },
]
const LINKS = { try: '/launch', demo: '#demo', explore: '/studio' }

export function SpaceHero() {
  const rootRef = useRef<HTMLDivElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const lastCtaRef = useRef<HTMLAnchorElement>(null)
  const [open, setOpen] = useState(false)

  // Entrance animation: plays once, then the intro classes are removed.
  useEffect(() => {
    const root = rootRef.current
    if (!root) return
    const clear = () => root.classList.remove('intro', 'intro-play')
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { clear(); return }

    root.classList.add('intro')
    const timers: number[] = []
    const failsafe = window.setTimeout(clear, 5000)
    timers.push(failsafe)
    let started = false
    let raf = 0
    const last = lastCtaRef.current
    const onEnd = (e: AnimationEvent) => { if (e.target === last) clear() }
    const start = () => {
      if (started) return
      started = true
      root.classList.add('intro-play')
      last?.addEventListener('animationend', onEnd)
      timers.push(window.setTimeout(clear, 3000))
    }
    const go = () => { raf = requestAnimationFrame(() => { raf = requestAnimationFrame(start) }) }
    // Never reveal the mask text in a fallback font.
    const fontTimer = window.setTimeout(go, 700)
    timers.push(fontTimer)
    document.fonts?.ready.then(() => { window.clearTimeout(fontTimer); go() })
    return () => { timers.forEach(clearTimeout); cancelAnimationFrame(raf); last?.removeEventListener('animationend', onEnd) }
  }, [])

  // Background video: autoplay attribute alone is unreliable.
  useEffect(() => {
    const v = videoRef.current
    if (!v) return
    v.muted = true
    const play = () => { if (v.paused) v.play().catch(() => {}) }
    const onVis = () => { if (document.visibilityState === 'visible') play() }
    const once = () => { play(); ['pointerdown', 'touchstart', 'scroll'].forEach(t => window.removeEventListener(t, once)) }
    play()
    v.addEventListener('canplay', play)
    document.addEventListener('visibilitychange', onVis)
    ;['pointerdown', 'touchstart', 'scroll'].forEach(t => window.addEventListener(t, once, { passive: true }))
    return () => {
      v.removeEventListener('canplay', play)
      document.removeEventListener('visibilitychange', onVis)
      ;['pointerdown', 'touchstart', 'scroll'].forEach(t => window.removeEventListener(t, once))
    }
  }, [])

  // Mobile menu: outside click and Escape close it.
  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (!(e.target as Element | null)?.closest('.bar')) setOpen(false)
    }
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false) }
    document.addEventListener('click', onDoc)
    document.addEventListener('keydown', onKey)
    return () => { document.removeEventListener('click', onDoc); document.removeEventListener('keydown', onKey) }
  }, [])

  return (
    <div ref={rootRef} className="hx intro">
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
      <link rel="stylesheet" href={FONT_HREF} precedence="default" />

      <video
        ref={videoRef}
        className="sky"
        aria-hidden="true"
        autoPlay
        muted
        loop
        playsInline
        preload="auto"
        poster={POSTER_SRC}
        src={VIDEO_SRC}
      />
      <div className="veil" />

      <header className="bar" data-open={open ? 'true' : 'false'}>
        <a className="brand" href="/" aria-label={`${BRAND} — home`}>
          <svg viewBox="0 0 26.9 16.6" fill="none" aria-hidden="true">
            <ellipse cx="13.25" cy="8.4" rx="13.2" ry="2.9" transform="rotate(-25 13.25 8.4)" stroke="currentColor" strokeWidth="1.25" />
            <circle cx="13.25" cy="8.4" r="8.8" fill="#000" />
            <circle cx="13.25" cy="8.4" r="8.1" fill="currentColor" />
            <ellipse cx="13.25" cy="8.4" rx="13.2" ry="2.9" transform="rotate(-25 13.25 8.4)" stroke="#000" strokeWidth="0.9" strokeDasharray="28.2 28.2" />
            <ellipse cx="13.25" cy="8.4" rx="13.2" ry="2.9" transform="rotate(-25 13.25 8.4)" stroke="currentColor" strokeWidth="1.25" strokeDasharray="28.2 28.2" />
          </svg>
          <span>{BRAND}</span>
        </a>

        <nav className="links" aria-label="Primary">
          {NAV.map(n => <a key={n.label} href={n.href}>{n.label}</a>)}
        </nav>

        <div className="actions">
          <a className="btn ghost" href={LINKS.try}>Try for free</a>
          <a className="btn solid" href={LINKS.demo}>Get a demo</a>
          <button
            className="menu"
            id="menu-btn"
            type="button"
            aria-label={open ? 'Close menu' : 'Menu'}
            aria-expanded={open}
            aria-controls="menu-sheet"
            onClick={e => { e.stopPropagation(); setOpen(o => !o) }}
          >
            <svg viewBox="0 0 20 14" fill="none" aria-hidden="true">
              <path d="M0 1h20M0 7h20M0 13h20" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
            </svg>
          </button>
          <nav className="sheet" id="menu-sheet" aria-label="Menu">
            {NAV.map(n => <a key={n.label} href={n.href}>{n.label}</a>)}
            <a className="btn solid" href={LINKS.demo}>Get a demo</a>
          </nav>
        </div>
      </header>

      <div className="screen">
        <main className="hero">
          <a className="pill" href="#new">
            <span className="chip">New</span>
            <span className="pill-label">Go beyond the ordinary</span>
            <svg viewBox="0 0 9.5 8" fill="none" aria-hidden="true">
              <path d="M0.7 4H8.8M5.6 0.75 8.85 4 5.6 7.25" stroke="currentColor" strokeWidth="1.35" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </a>

          <h1>
            <span className="ln"><span className="ln-i">See beyond now</span></span>
            <span className="ln"><span className="ln-i">Explore the stars</span></span>
          </h1>

          <p>Everything you need to discover, understand, and explore what is out there.</p>

          <div className="cta">
            <a className="btn ghost" href={LINKS.try}>Try for free</a>
            <a ref={lastCtaRef} className="btn solid" href={LINKS.explore}>Explore</a>
          </div>
        </main>
      </div>
    </div>
  )
}
