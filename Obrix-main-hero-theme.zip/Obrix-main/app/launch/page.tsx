"use client";

import { LaunchForm } from "@/components/launch-page/launch-form";

export default function LaunchPage() {
  return (
    <main className="obrix-launch-page min-h-screen">
      <header className="border-b border-white/10 px-5 py-4">
        <a href="/" className="text-sm tracking-[0.3em]">
          ⬡ OBRIX
        </a>
        <p className="mt-2 text-xs opacity-60">
          PONS V2 · ROBINHOOD CHAIN
        </p>
      </header>

      <section className="mx-auto grid w-full max-w-6xl gap-10 px-5 py-12 md:grid-cols-2 md:py-20">
        <div>
          <p className="text-xs tracking-[0.25em] opacity-60">
            OBRIX / LAUNCH STUDIO
          </p>
          <h1 className="mt-5 text-4xl font-normal tracking-tight md:text-6xl">
            From idea
            <br />
            to on-chain.
          </h1>
          <p className="mt-5 max-w-sm text-sm leading-7 opacity-70">
            Create your token through Pons V2. Your wallet signs transactions
            directly; OBRIX never takes custody of your funds.
          </p>
          <a
            href="/"
            className="mt-8 inline-block text-sm underline underline-offset-4"
          >
            ← Back to OBRIX
          </a>
        </div>

        <div id="launch-form" className="min-w-0">
          <LaunchForm
            onSubmit={async (data) => {
              console.log("OBRIX launch form submitted", data);
            }}
          />
        </div>
      </section>
    </main>
  );
}
