import type { Metadata } from 'next'
import { SpaceHero } from '@/components/hero/space-hero'

export const metadata: Metadata = {
  title: 'Obrix — See beyond now',
  description: 'Everything you need to discover, understand, and explore what is out there.',
}

export default function Home() {
  return <SpaceHero />
}
