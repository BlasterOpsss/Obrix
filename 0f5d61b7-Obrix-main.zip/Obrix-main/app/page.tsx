'use client'

import { useEffect, useState } from 'react'
import { Navbar } from '@/components/launch-page/navbar'
import { LaunchForm } from '@/components/launch-page/launch-form'
import { TokenPreview } from '@/components/launch-page/token-preview'
import ObrixRobot from '@/components/launch-page/obrix-robot'

type LaunchFormData = {
  tokenImage: File | null
  tokenImagePreview: string | null
  logoUri: string
  tokenName: string
  tokenSymbol: string
  description: string
  xLink: string
  telegram: string
  website: string
  developerBuy: number
  feeReceiver: string
}

const prompts = [
  'Create a smart contract for a token named OBRIX on Robinhood Chain.',
  'Explain what a smart contract does in simple terms.',
  'Audit this contract for reentrancy vulnerabilities.',
  'Analyze the crypto market and discover new opportunities.',
]

const reviews = [
  {
    quote: 'A cleaner way to turn an idea into an on-chain launch experience.',
    name: 'Early Builder',
    role: 'WEB3 COMMUNITY',
  },
  {
    quote: 'A thoughtful interface for exploring the next generation of on-chain tools.',
    name: 'Product Explorer',
    role: 'ON-CHAIN INNOVATION',
  },
  {
    quote: 'Simple, focused, and built around the creator experience.',
    name: 'Token Creator',
    role: 'WEB3 ECOSYSTEM',
  },
]

export default function Home() {
  const [formData, setFormData] = useState<LaunchFormData>({
    tokenImage: null,
    tokenImagePreview: null,
    logoUri: '',
    tokenName: '',
    tokenSymbol: '',
    description: '',
    xLink: '',
    telegram: '',
    website: '',
    developerBuy: 0,
    feeReceiver: '',
  })
  const [announcement, setAnnouncement] = useState(true)
  const [promptIndex, setPromptIndex] = useState(0)
  const [typedPrompt, setTypedPrompt] = useState('')
  const [reviewIndex, setReviewIndex] = useState(0)
  const [reviewVisible, setReviewVisible] = useState(true)
  const [activeSection, setActiveSection] = useState('INTRO')

  useEffect(() => {
    let index = 0
    let deleting = false
    let timeout: ReturnType<typeof setTimeout>

    const type = () => {
      const target = prompts[promptIndex]
      if (!deleting) {
        index++
        setTypedPrompt(target.slice(0, index))
        if (index >= target.length) {
          deleting = true
          timeout = setTimeout(type, 2600)
          return
        }
        timeout = setTimeout(type, 38)
      } else {
        index = Math.max(0, index - 2)
        setTypedPrompt(target.slice(0, index))
        if (index <= 0) {
          deleting = false
          setPromptIndex((old) => (old + 1) % prompts.length)
          timeout = setTimeout(() => {
            index = 0
            setTypedPrompt('')
          }, 250)
          return
        }
        timeout = setTimeout(type, 14)
      }
    }

    timeout = setTimeout(type, 500)
    return () => clearTimeout(timeout)
  }, [promptIndex])

  useEffect(() => {
    const nodes = document.querySelectorAll<HTMLElement>('.obrix-reveal')
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const element = entry.target as HTMLElement
          const delay = Number(element.dataset.delay || 0)
          setTimeout(() => element.classList.add('is-visible'), delay)
          observer.unobserve(element)
        }
      })
    }, { threshold: 0.15 })

    nodes.forEach((node) => observer.observe(node))
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    const update = () => {
      const sections = ['intro', 'product', 'reviews']
      let active = 'INTRO'
      sections.forEach((id) => {
        const el = document.getElementById(id)
        if (el && el.getBoundingClientRect().top < window.innerHeight * 0.5) {
          active = id.toUpperCase()
        }
      })
      setActiveSection(active)
    }
    window.addEventListener('scroll', update, { passive: true })
    update()
    return () => window.removeEventListener('scroll', update)
  }, [])

  const handleFormSubmit = async (data: LaunchFormData) => {
    setFormData(data)
    console.log('OBRIX form submitted. Connect this handler to the verified Pons V2 launch flow.')
  }

  const changeReview = (direction: number) => {
    setReviewVisible(false)
    setTimeout(() => {
      setReviewIndex((old) => (old + direction + reviews.length) % reviews.length)
      setReviewVisible(true)
    }, 450)
  }

  const review = reviews[reviewIndex]

  return (
    <div className="obrix-site obrix-paper-grid">
      <ObrixRobot />

      {announcement && (
        <div className="obrix-announcement">
          <span><strong>New:</strong> OBRIX — a new on-chain launch experience ↗</span>
          <button aria-label="Dismiss announcement" onClick={() => setAnnouncement(false)}>×</button>
        </div>
      )}

      <div className="obrix-nav-wrap">
        <Navbar />
      </div>

      <aside className="obrix-rail" aria-label="Page sections">
        <div className="obrix-rail-dots">
          {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13].map((n) => (
            <span key={n} />
          ))}
        </div>
        <div className="obrix-rail-label">{activeSection}</div>
        <a href="#product">≡ MENU</a>
      </aside>

      <main className="obrix-content">
        <section id="intro" className="obrix-section obrix-intro">
          <div className="obrix-prompt obrix-reveal" data-delay="100">
            <div className="obrix-quote-tab">“</div>
            <div className="obrix-prompt-box">
              <span>{typedPrompt}</span><i className="obrix-caret" />
            </div>
            <p className="obrix-prompt-next">{prompts[(promptIndex + 1) % prompts.length]}</p>
          </div>

          <div className="obrix-rule obrix-reveal" data-delay="200" />
          <div className="obrix-features obrix-reveal" data-delay="300">
            {['ON-CHAIN LAUNCHES', 'SMART CONTRACTS', 'AI & MARKET TOOLS', 'AND MUCH MORE'].map((item, i) => (
              <div className={i === 3 ? 'is-dim' : ''} key={item}>
                <span className="obrix-feature-dot" />{item}
              </div>
            ))}
          </div>

          <div className="obrix-intro-title obrix-reveal" data-delay="200">
            <p className="obrix-eyebrow">BUILD THE NEXT ON-CHAIN IDEA</p>
            <h1><span className="obrix-headline-frame">Thinking</span><br /><span className="obrix-headline-frame obrix-headline-second">Machines</span></h1>
          </div>

          <p className="obrix-intro-sub obrix-reveal" data-delay="400">
            Your gateway to a more thoughtful on-chain launch experience.
          </p>
          <a className="obrix-scroll" href="#product">SCROLL <span>↓</span></a>
          <div className="obrix-bottom-rule" />
        </section>

        <section id="product" className="obrix-section obrix-product">
          <div className="obrix-tab-strip obrix-reveal">
            {[
              'Launchpad', 'Token creation', 'On-chain tools', 'Market insights',
              'AI assistant', 'Smart contracts', 'Creator tools', 'Web3 analytics',
              'Token preview', 'Launchpad',
            ].map((label, i) => (
              <div className={`obrix-tab ${i === 0 ? 'is-active' : ''}`} key={`${label}-${i}`}>
                <span>{String(i + 1).padStart(2, '0')}</span><strong>{label}</strong>
              </div>
            ))}
          </div>

          <div className="obrix-product-heading obrix-reveal" data-delay="100">
            <span className="obrix-eyebrow">··</span>
            <h2><span className="obrix-heading-frame">Your Gateway</span><br />To Web3</h2>
            <p>Create and preview your token using the OBRIX launch interface.</p>
          </div>

          <div className="obrix-launch-layout obrix-reveal" data-delay="200">
            <div className="obrix-launch-copy">
              <span className="obrix-eyebrow">OBRIX / LAUNCH STUDIO</span>
              <h3>From idea<br />to on-chain.</h3>
              <p>Your wallet signs transactions directly. OBRIX does not take custody of your funds.</p>
            </div>
            <div className="obrix-form-shell">
              <LaunchForm onSubmit={handleFormSubmit} onChange={setFormData} />
              <div className="obrix-preview-shell">
                <TokenPreview
                  image={formData.tokenImagePreview || undefined}
                  name={formData.tokenName}
                  symbol={formData.tokenSymbol}
                  description={formData.description}
                  xLink={formData.xLink}
                  telegram={formData.telegram}
                  website={formData.website}
                />
              </div>
            </div>
          </div>
        </section>

        <section id="reviews" className="obrix-section obrix-reviews">
          <header className="obrix-review-header obrix-reveal">
            <span>TSTMNL</span>
            <span className="obrix-review-number">[{String(reviewIndex + 1).padStart(2, '0')}]</span>
            <div className="obrix-avatar" aria-hidden="true">
              <svg viewBox="0 0 56 56" width="56" height="56">
                <rect width="56" height="56" fill="#d7c4b4" />
                <path d="M0 12h56M0 24h56M0 36h56M0 48h56" stroke="#ad7765" strokeWidth="3" />
                <circle cx="28" cy="21" r="10" fill="#f0d0b5" />
                <path d="M16 21q0-17 13-15 13 1 12 16l-5-8-15 1z" fill="#282522" />
                <path d="M9 56q2-22 19-22t19 22" fill="#3c4649" />
              </svg>
            </div>
            <span className="obrix-review-person">{review.name}</span>
            <span className="obrix-review-role">{review.role}</span>
          </header>

          <div className={`obrix-review-body ${reviewVisible ? 'is-visible' : ''}`}>
            <div className="obrix-review-quote">
              <span className="obrix-eyebrow">A WORD FROM THE COMMUNITY</span>
              <blockquote>“{review.quote}”</blockquote>
              <a href="#product"><span />Explore OBRIX for yourself ↗</a>
            </div>
            <div className="obrix-review-ghost">“{reviews[(reviewIndex + 1) % reviews.length].quote}”</div>
          </div>

          <div className="obrix-review-arrows">
            <button aria-label="Previous review" onClick={() => changeReview(-1)}>←</button>
            <button aria-label="Next review" onClick={() => changeReview(1)}>→</button>
          </div>
          <footer className="obrix-footer">OBRIX · ON-CHAIN TOOLS · 2026</footer>
        </section>
      </main>
    </div>
  )
}
